package com.nyfaria.nyfsspiders;

import net.fabricmc.api.ModInitializer;

public class NyfsSpiders implements ModInitializer {
    
    @Override
    public void onInitialize() {
        CommonClass.init();
    }
}
