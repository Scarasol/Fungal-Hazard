package com.nyfaria.nyfsspiders;

import net.fabricmc.api.ClientModInitializer;

public class NyfsSpidersClient implements ClientModInitializer {
    
    @Override
    public void onInitializeClient() {

    }
}
