## Version 2.1.1
- Fixed crash from other mods setting navigation too early in the lifecycle of a spider.

## Version 2.1.0
- 1.20.x port