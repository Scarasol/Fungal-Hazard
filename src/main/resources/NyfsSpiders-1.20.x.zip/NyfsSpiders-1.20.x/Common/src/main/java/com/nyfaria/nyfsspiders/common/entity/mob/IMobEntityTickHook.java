package com.nyfaria.nyfsspiders.common.entity.mob;

public interface IMobEntityTickHook {
	public void onTick();
}
