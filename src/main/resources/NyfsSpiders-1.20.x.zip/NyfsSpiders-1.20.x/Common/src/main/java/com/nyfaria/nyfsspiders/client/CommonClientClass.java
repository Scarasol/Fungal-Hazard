package com.nyfaria.nyfsspiders.client;

public class CommonClientClass {

}
