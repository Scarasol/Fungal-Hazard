package com.nyfaria.nyfsspiders.common.entity.mob;

public interface IMobEntityRegisterGoalsHook {
	public void onRegisterGoals();
}
