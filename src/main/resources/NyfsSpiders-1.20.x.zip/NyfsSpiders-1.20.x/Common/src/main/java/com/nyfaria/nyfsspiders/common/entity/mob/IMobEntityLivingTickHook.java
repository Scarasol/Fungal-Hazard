package com.nyfaria.nyfsspiders.common.entity.mob;

public interface IMobEntityLivingTickHook {
	public void onLivingTick();
}
